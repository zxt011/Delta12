module.exports = {
  'approval': {
    'num': '6282135574623',
    'text': "setujui",
    'set': "👀 Harus mendapatkan persetujuan oleh creator script, Jika ingin memakai script ini",
    'greet': "*Disetujui Oleh Creator, Silahkan Restart Panel Atau Run Ulang script* ☠️ "
  },
  'creatorScript': '6282135574623',
  'filePath': "./slide/vocado.co",
  'checkFilePath': "../avocado.js",
  'codeToDetect': 'main();'
};