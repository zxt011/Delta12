// PERINGATAN SEBELUM MENGSETING WAJIB BAJA DI FILE note.text JIKA BELUM PAHAM BISA BAJA DI FILE note.texy
const fs = require("fs");
// API RUMAH TOPUP //
global.rumahtopupkey = "Apikey"
global.rumahtopupid = "apiid"

/// API TRIPAY ///
global.privatekey = "sqyHe-5yk7S-F6fIU-b4fZk-THGPW"// isi private key
global.keytripay = "ZVtT0jLqKJDEM9e9My0zAyutcE0z3WCHjt2a0GO7" //isi apikey 
global.merchant = "T24775" // isi merchant kode

global.koneksi   = "62"   // isi nomor
global.keuntungan = 0 // isi keuntungan jualan
global.owner = "Rumah Media" // NAMA OWNER
global.sessionName = 'yasstopup' //Gausah Juga
global.thumb = fs.readFileSync("./image/foto.jpg")
exports.Config = {
	botName: "Nama Bot",
	ownerName: "Nama Owner",
	ampangPedia: {
	
	},
	APIs: {
		rose: "https://api.itsrose.life",
		apikey: "NVF2Abx8N8nLyc38Iv5pvrls3FylRmZxn6u4OFJNX3DxfzgNUqH3rvk2QT0gsCtj", // cek website to get apikey
	},

     //Gausah Jug
	// ubah se
    
	groupLink: "Link Gc",
	footer: "*RumahMedia*",
	sticker: {
		packname: "PackName Mu",
		author: "Nqma mu"
	},
	// cek folder image, timpa file
	pp_bot: fs.readFileSync("./image/foto.jpg"),
	qris: fs.readFileSync("./image/photo.jpg"),

	owner: ["62xxxxxx"],
	prefa: ["1", "2"],

	caption_pay: `Berikut List Payment Kami

Ovo ➪   Isi
Dana ➪  082310906429
Gopay ➪ Isi

`,
	helpMenu: (name) => {
		return `INFO DASHBOARD°•

✦ *CARA TRANSAKSI* ✦
: ̗̀➛ topup [kode] [tujuan]

✦ Menu Store ✦
  : ̗̀➛ topup
  : ̗̀➛ pricelist 
  : ̗̀➛ saldo
  : ̗̀➛ cekstatus
  : ̗̀➛ proses
  : ̗̀➛ Done

✦ Menu Other ✦
  : ̗̀➛ pay
  : ̗̀➛ hidetag
  : ̗̀➛ donasi
  : ̗̀➛ seticker
  : ̗̀➛ adminmenu

_©PT RUMAH TOPUP DIGITAL_`;
	},
};
exports.mess = {
	rowAdmin: "Fitur Khusus admin & owner!",
	admin: "Fitur Khusus admin!",
	group: "Fitur Khusus Group!",
	owner: "Fitur kuhusu owner!",
	botAdmin: "Jadikan bot sebagai admin terlebih dahulu",
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
	fs.unwatchFile(file);
	console.log(`Update ${__filename}`);
	delete require.cache[file];
	require(file);
});