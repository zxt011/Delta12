//━━━━━━━━━━━━━━━[ YASS DEVELOPER ]━━━━━━━━━━━━━━━━━//

// @YASS DEVELOPER 
// [ 082122354307 ] 
// NO JUAL SCRIPIT INI HARGAI YG BUAT @YASS DEVOLOPER
// TQTO
// ALLAH ( SWT )
// PENYEMANGAT KU 
// ORANG-TUA
// YASSDEV ( SAYA )
// Kebohongan hanya akan menyelamatkanmu sementara, tapi menghancurkanmu selamanya." @YassDev /

require(`./config.js`)
const { default: makeWASocket, DisconnectReason, downloadContentFromMessage, useMultiFileAuthState, jidDecode, areJidsSameUser, makeInMemoryStore } = require('@whiskeysockets/baileys')
const PhoneNumber = require('awesome-phonenumber')
const fs = require('fs')
const pino = require('pino')
const FileType = require('file-type')
const { Boom } = require('@hapi/boom')
const { smsg } = require('./myfunc')
const { getBuffer, fetchJson } = require("./lib/simple"),
	{
		isSetClose,
		addSetClose,
		removeSetClose,
		changeSetClose,
		getTextSetClose,
		isSetDone,
		addSetDone,
		removeSetDone,
		changeSetDone,
		getTextSetDone,
		isSetLeft,
		addSetLeft,
		removeSetLeft,
		changeSetLeft,
		getTextSetLeft,
		isSetOpen,
		addSetOpen,
		removeSetOpen,
		changeSetOpen,
		getTextSetOpen,
		isSetProses,
		addSetProses,
		removeSetProses,
		changeSetProses,
		getTextSetProses,
		isSetWelcome,
		addSetWelcome,
		removeSetWelcome,
		changeSetWelcome,
		getTextSetWelcome,
		addSewaGroup,
		getSewaExpired,
		getSewaPosition,
		expiredCheck,
		checkSewaGroup,
	} = require("./lib/store");
let set_welcome_db = JSON.parse(fs.readFileSync("./database/set_welcome.json"));
let set_left_db = JSON.parse(fs.readFileSync("./database/set_left.json")),
	_welcome = JSON.parse(fs.readFileSync("./database/welcome.json"));
let _left = JSON.parse(fs.readFileSync("./database/left.json")),
	set_proses = JSON.parse(fs.readFileSync("./database/set_proses.json")),
	set_done = JSON.parse(fs.readFileSync("./database/set_done.json")),
	set_open = JSON.parse(fs.readFileSync("./database/set_open.json"));
let set_close = JSON.parse(fs.readFileSync("./database/set_close.json"));
let sewa = JSON.parse(fs.readFileSync("./database/sewa.json")),
	opengc = JSON.parse(fs.readFileSync("./database/opengc.json")),
	antilink = JSON.parse(fs.readFileSync("./database/antilink.json"));
let antiwame = JSON.parse(fs.readFileSync("./database/antiwame.json")),
	db_respon_list = JSON.parse(fs.readFileSync("./database/list.json"));
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./exif')
const chalk = require('chalk')
const readline = require("readline");
const CFonts = require('cfonts')
const yargs = require('yargs/yargs')
const _ = require('lodash')
const spin = require('spinnies')
const color = (text, color) => { return !color ? chalk.green(text) : chalk.keyword(color)(text) }
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })
let d = new Date
let locale = 'id'
let gmt = new Date(0).getTime() - new Date('1 Januari 2021').getTime()
let weton = ['Pahing', 'Pon','Wage','Kliwon','Legi'][Math.floor(((d * 1) + gmt) / 84600000) % 5]
let week = d.toLocaleDateString(locale, { weekday: 'long' })
const calender = d.toLocaleDateString("id", {
day: 'numeric',
month: 'long',
year: 'numeric'
})
const usePairingCode = true
const question = (text) => {
  const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
  });
  return new Promise((resolve) => {
rl.question(text, resolve)
  })
};
const spinner = { 
  "interval": 120,
  "frames": [
"︵‿︵‿︵‿︵‿︵‿︵‿︵",
"‿︵‿︵‿︵‿︵‿︵‿︵‿",
"︵‿︵‿︵‿︵‿︵‿︵‿︵",
"‿︵‿︵‿︵‿︵‿︵‿︵‿",
"︵‿︵‿︵‿︵‿︵‿︵‿︵",
"‿︵‿︵‿︵‿︵‿︵‿︵‿",
"︵‿︵‿︵‿︵‿︵‿︵‿︵",
"‿︵‿︵‿︵‿︵‿︵‿︵‿",
"︵‿︵‿︵‿︵‿︵‿︵‿︵",
"‿︵‿︵‿︵‿︵‿︵‿︵‿",
"︵‿︵‿︵‿︵‿︵‿︵‿︵",
"‿︵‿︵‿︵‿︵‿︵‿︵‿",
"︵‿︵‿︵‿︵‿︵‿︵‿︵",
"‿︵‿︵‿︵‿︵‿︵‿︵‿",
"︵‿︵‿︵‿︵‿︵‿︵‿︵",
"‿︵‿︵‿︵‿︵‿︵‿︵‿"
  ]}
let globalSpinner;
const getGlobalSpinner = (disableSpins = false) => {
if(!globalSpinner) globalSpinner = new spin({ color: 'crimson', succeedColor: 'green', spinner, disableSpins});
return globalSpinner;
}
let spins = getGlobalSpinner(false)
const start = (id, text) => {
spins.add(id, {text: text})
}
const success = (id, text) => {
spins.succeed(id, {text: text})

}
//=================================================//
CFonts.say("BOT TOP UP OTOMATIS", {
   font: 'chrome',
  align: 'left',
  gradient: ['red', 'magenta'],
});
CFonts.say(
  "Sc Bot Topup Otomotis\nBase: Ori Kangcoding\nRecodeBy:Pt Rumah Topup\nHwVersion:03\nRuning:Panel\n\n\nSc Ini Udah No Enc, Jangan Dijual Sat!\n\n\n",
  {
    colors: ["system"],
    font: "console",
    align: "center",
  },
);
console.log(color(`INFO:`, "red"), color(`\n𖦹`, "yellow"), color(`Jika code tidak muncul enter 1-2x lagi`, "green"), color(`\n𖦹`, "yellow"), color(`Type nomor harus 62xxx bukan 08xxx\n`, "green"))
//=================================================//
async function connectToWhatsApp() {
const { state, saveCreds } = await useMultiFileAuthState(global.sessionName)
const client = makeWASocket({
logger: pino({ level: "silent" }),
printQRInTerminal: !usePairingCode,
auth: state,
browser: ['Ubuntu', 'Chrome', '20.0.04']
});
if(usePairingCode && !client.authState.creds.registered) {
		const phoneNumber = await question(color('\n\n\nSilahkan masukin nomor Whatsapp Awali dengan 62:\n', 'magenta'));
		const code = await client.requestPairingCode(phoneNumber.trim())
		console.log(color(`⚠︎ Kode Pairing Bot Whatsapp kamu :`,"gold"), color(`${code}`, "white"))

	}

//=================================================//

    

client.ev.on('messages.upsert', async chatUpdate => {
try {
m = chatUpdate.messages[0]
if (!m.message) return
m.message = (Object.keys(m.message)[0] === 'ephemeralMessage') ? m.message.ephemeralMessage.message : m.message
if (!client.public && !m.key.fromMe && chatUpdate.type === 'notify') return
if (m.key.id.startsWith('BAE5') && m.key.id.length === 16) return
msg = smsg(client, m, store)
require('./handler')(client,
				m,
				msg,
				store,
				opengc,
				antilink,
				antiwame,
				set_welcome_db,
				set_left_db,
				set_proses,
				set_done,
				set_open,
				set_close,
				sewa,
				_welcome,
				_left,
				db_respon_list)
} catch (err) {
console.log(err)}})
    
    
    client.ev.on("groups.update", async (participants) => {
		try {
			for (let x of participants) {
				try {
					ppgc = await client.profilePictureUrl(x.id, "image");
				} catch {
					ppgc = "https://telegra.ph/file/c3f3d2c2548cbefef1604.jpg";
				}
				if (x.announce == true) {
					client.sendMessage(x.id, {
						image: { url: ppgc },
						caption:
							"*\u300C Group Update Detected \u300D*\n\nGroup telah ditutup, Sekarang hanya admin yang dapat mengirim pesan !",
					});
				} else {
					if (x.announce == false) {
						client.sendMessage(x.id, {
							image: { url: ppgc },
							caption:
								"*\u300C Group Update Detected \u300D*\n\nGroup telah dibuka, Sekarang peserta dapat mengirim pesan !",
						});
					} else {
						if (x.restrict == true) {
							client.sendMessage(x.id, {
								image: { url: ppgc },
								caption:
									"*\u300C Group Update Detected \u300D*\n\nInfo group telah dibatasi, Sekarang hanya admin yang dapat mengedit info group !",
							});
						} else {
							if (x.restrict == false) {
								client.sendMessage(x.id, {
									image: { url: ppgc },
									caption:
										"*\u300C Group Update Detected \u300D*\n\nInfogroup telah dibuka, Sekarang peserta dapat mengedit info group !",
								});
							} else {
								client.sendMessage(x.id, {
									image: { url: ppgc },
									caption:
										"*\u300C Group Update Detected \u300D*\n\nNama Group telah diganti menjadi *" +
										x.subject +
										"*",
								});
							}
						}
					}
				}
			}
		} catch (e) {
			console.log(e);
		}
	});
client.ev.on("group-participants.update", async (group) => {
		const isWelcome = _welcome.includes(group.id),
			isLeft = _left.includes(group.id);
		try {
			let metadata = await client.groupMetadata(group.id),
				participants = group.participants;
			const subject = metadata.subject,
				desc = metadata.desc;
			for (let user of participants) {
				try {
					ppuser = await client.profilePictureUrl(user, "image");
				} catch {
					ppuser = "https://telegra.ph/file/c3f3d2c2548cbefef1604.jpg";
				}
				try {
					ppgroup = await sock.profilePictureUrl(group.id, "image");
				} catch {
					ppgroup = "https://telegra.ph/file/c3f3d2c2548cbefef1604.jpg";
				}
				if (group.action == "add" && isWelcome) {
					console.log(group);
					if (isSetWelcome(group.id, set_welcome_db)) {
						var textWelcome = await getTextSetWelcome(group.id, set_welcome_db),
							pesan = textWelcome.replace(/@user/gi, "@" + user.split("@")[0]);
						sock.sendMessage(group.id, {
							image: { url: ppuser },
							mentions: [user],
							caption:
								"" +
								pesan.replace(/@group/gi, subject).replace(/@desc/gi, desc),
						});
					} else {
						client.sendMessage(group.id, {
							image: { url: ppuser },
							mentions: [user],
							caption:
								"Halo @" +
								user.split("@")[0] +
								", Welcome To " +
								metadata.subject,
						});
					}
				} else {
					if (group.action == "remove" && isLeft) {
						console.log(group);
						if (isSetLeft(group.id, set_left_db)) {
							var textLeft = await getTextSetLeft(group.id, set_left_db),
								pesan = textLeft.replace(/@user/gi, "@" + user.split("@")[0]);
							sock.sendMessage(group.id, {
								image: { url: ppuser },
								mentions: [user],
								caption:
									"" +
									pesan.replace(/@group/gi, subject).replace(/@desc/gi, desc),
							});
						} else {
							client.sendMessage(group.id, {
								image: { url: ppuser },
								mentions: [user],
								caption: "Sayonara @" + user.split("@")[0],
							});
						}
					} else {
						if (group.action == "promote") {
							sock.sendMessage(group.id, {
								image: { url: ppuser },
								mentions: [user],
								caption:
									"@" +
									user.split("@")[0] +
									" sekaran menjadi admin grup " +
									metadata.subject,
							});
						} else {
							if (group.action == "demote") {
								sock.sendMessage(group.id, {
									image: { url: ppuser },
									mentions: [user],
									caption:
										"@" +
										user.split("@")[0] +
										" bukan admin grup " +
										metadata.subject +
										" lagi",
								});
							}
						}
					}
				}
			}
		} catch (e) {
			console.log(e);
		}
	});
client.decodeJid = (jid) => {
if (!jid) return jid
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {}
return decode.user && decode.server && decode.user + '@' + decode.server || jid
} else return jid
}

client.ev.on('contacts.update', update => {
for (let contact of update) {
let id = client.decodeJid(contact.id)
if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
}
})
  
client.getName = (jid, withoutContact  = true) => {
id = client.decodeJid(jid)
withoutContact = client.withoutContact || withoutContact 
let v
if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
v = store.contacts[id] || {}
if (!(v.name || v.subject)) v = client.groupMetadata(id) || {}
resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
})
else v = id === '0@s.whatsapp.net' ? {
id,
name: 'WhatsApp'
} : id === client.decodeJid(client.user.id) ?
client.user :
(store.contacts[id] || {})
return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
}

client.public = true
    
    client.ev.on('creds.update', saveCreds)

client.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
let quoted = message.msg ? message.msg : message
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(quoted, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
let type = await FileType.fromBuffer(buffer)
trueFileName = attachExtension ? (filename + '.' + type.ext) : filename
await fs.writeFileSync(trueFileName, buffer)
return trueFileName
}

client.downloadMediaMessage = async (message) => {
let mime = (message.msg || message).mimetype || ''
let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
const stream = await downloadContentFromMessage(message, messageType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
return buffer
}

const { getImg } = require('./functions')

client.sendImage = async (jid, path, caption = '', quoted = '', options) => {
let buffer = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getImg(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
return await client.sendMessage(jid, { image: buffer, caption: caption, ...options }, { quoted })
}

client.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getImg(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let buffer
if (options && (options.packname || options.author)) {
buffer = await writeExifImg(buff, options)
} else {
buffer = await imageToWebp(buff)
}
await client.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted })
return buffer
}

client.sendButMessage = (jid, buttons = [], text, footer, quoted = '', options = {}) => {
let buttonMessage = {
text,
footer,
buttons,
headerType: 2,
...options
}
client.sendMessage(jid, buttonMessage, { quoted, ...options })
}
client.serializeM = (m) => smsg(client, m, store)
client.ev.on("connection.update", async (update) => {
const { connection, lastDisconnect } = update;
if (connection === "close") {
  let reason = new Boom(lastDisconnect?.error)?.output.statusCode;
  if (reason === DisconnectReason.badSession) {
console.log(`Bad Session File, Please Delete Session and Scan Again`);
process.exit();
  } else if (reason === DisconnectReason.connectionClosed) {
console.log("Connection closed, reconnecting....");
connectToWhatsApp();
  } else if (reason === DisconnectReason.connectionLost) {
console.log("Connection Lost from Server, reconnecting...");
connectToWhatsApp();
  } else if (reason === DisconnectReason.connectionReplaced) {
console.log("Connection Replaced, Another New Session Opened, Please Restart Bot");
process.exit();
  } else if (reason === DisconnectReason.loggedOut) {
console.log(`Device Logged Out, Please Delete Folder Session yusril and Scan Again.`);
process.exit();
  } else if (reason === DisconnectReason.restartRequired) {
console.log("Restart Required, Restarting...");
connectToWhatsApp();
  } else if (reason === DisconnectReason.timedOut) {
console.log("Connection TimedOut, Reconnecting...");
connectToWhatsApp();
  } else {
console.log(`Unknown DisconnectReason: ${reason}|${connection}`);
connectToWhatsApp();
  }
} else if (connection === 'connecting') {
//console.log(`${color(`[`,`white`)+color(`1`,`red`)+color(`]`,`white`)}`,`WA v${version.join('.')}`)
//await sleep(400) 
console.log(`${color(`[`,`white`)+color(`2`,`red`)+color(`]`,`white`)}`,`${calender}`)
//await sleep(400) 
console.log(`${color(`[`,`white`)+color(`3`,`red`)+color(`]`,`white`)}`,`Base Sc:Yass`)
//await sleep(400)  
console.log(`${color(`[`,`white`)+color(`4`,`red`)+color(`]`,`white`)}`,"date 5") 
//await sleep(400)  
console.log(color(`─[`,`magenta`),`「`,  color(`YassStote`,`red`), `」`,  color(`]─`,`magenta`))
//await sleep(400)  
start(`1`,`Connecting...`)
} else if (connection === "open") {
  client.sendMessage(koneksi + "@s.whatsapp.net", { text: `*Version New*
  Telah Terhubung!!, Ketik .Menu untuk menampilkan command!
  
  *_Suport Terus Kang Coding._*
  
  *Kang Coding Bot Topup Otomatis*` });
  success(`1`,`[■■■■■■■■■■■■■■■] Connected`) 
}
// console.log('Connected...', update)
});
return client
}

connectToWhatsApp()